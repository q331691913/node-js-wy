const username = '张三'

function sayHello() {
  console.log('大家好，我是' + username)
}
