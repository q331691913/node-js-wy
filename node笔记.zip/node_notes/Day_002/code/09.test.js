const custom = require('./08.模块作用域')

console.log(custom)