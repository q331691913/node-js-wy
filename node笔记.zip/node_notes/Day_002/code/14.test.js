const m = require('./13.exports对象')
console.log(m)