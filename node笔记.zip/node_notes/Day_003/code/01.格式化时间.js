const moment = require('moment')

const dt = moment().format('YYYY-MM-DD')
console.log(dt)
