console.log('通过 package.json 加载了 a.js 文件')
